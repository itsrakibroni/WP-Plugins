<?php
/**
 * Plugin Name: ThemeVally Elementor Extension
 * Description: Custom Elementor extension.
 * Plugin URI:  https://elementor.com/
 * Version:     1.0.0
 * Author:      ThemeVally
 * Author URI:  https://elementor.com/
 * Text Domain: themevally-elementor-extension
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Require once the Composer Autoload
if(file_exists(dirname(__FILE__).'/vendor/autoload.php')){
	require_once dirname(__FILE__).'/vendor/autoload.php';
}



define( 'themevally_DIR_PATH', plugin_dir_path( __FILE__ ) );


require themevally_DIR_PATH . 'base.php';

require themevally_DIR_PATH . 'post-type/post-type.php';

require themevally_DIR_PATH . 'inc/icons.php';

require themevally_DIR_PATH . 'inc/metabox/meta-loader.php';


require_once(themevally_DIR_PATH. 'inc/widgets/em_about.php');
require_once(themevally_DIR_PATH. 'inc/widgets/em_recent_post.php');
require_once(themevally_DIR_PATH. 'inc/widgets/em_footer_portfolio.php');




