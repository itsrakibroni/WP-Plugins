<?php



use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if(!defined('ABSPATH')) exit;


class Testimonial extends Widget_Base{

	public function get_name(){
		return "testimonial";
	}
	
	public function get_title(){
		return "Testimonial";
	}
	
	public function get_icon(){
		return "eicon-blockquote";
	}
	public function get_categories(){
		return ['themevally-category'];
	}
	
	protected function _register_controls(){

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'textdomain' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'image',
			[
				'name'	=> 'image',
				'label' => __( 'Choose Image', 'themevally-elementor-extension' ),
				'type' => Controls_Manager::MEDIA,
			],
		);		
		
		$repeater->add_control(
			'quote_text',
			[
				'label' => __( 'Quote', 'themevally-elementor-extension' ),
				'type' => Controls_Manager::TEXTAREA,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Quote', 'themevally-elementor-extension' ),
				'label_block' => true,
				'default' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'themevally-elementor-extension' ),
			],
		);
		$repeater->add_control(
			'quote_title',
			[
				'label' => __( 'Title', 'themevally-elementor-extension' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Quote', 'themevally-elementor-extension' ),
				'label_block' => true,
				'default' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'themevally-elementor-extension' ),
			],
		);
		$repeater->add_control(
			'name',
			[
				'label' => __( 'Name', 'themevally-elementor-extension' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your name', 'themevally-elementor-extension' ),
				'default' => __( 'Your Name', 'themevally-elementor-extension' ),
			]
		);		
		$repeater->add_control(
			'quote_title',
			[
				'label' => __( 'Title', 'themevally-elementor-extension' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your name', 'themevally-elementor-extension' ),
				'default' => __( 'Your Name', 'themevally-elementor-extension' ),
			]
		);

		$repeater->add_control(
			'designation',
			[
				'label' => __( 'Designation', 'themevally-elementor-extension' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your designation', 'themevally-elementor-extension' ),
				'default' => __( 'Web Developer', 'themevally-elementor-extension' ),
			]
		);

		$repeater->add_control(
			'rating',
			[
				'label' => __( 'Rating', 'themevally-elementor-extension' ),
				'type' => Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 5,
				'step' => 1,
				'default' => 3,
			]
		);

		$this->add_control(
			'list',
			[
				'label' => esc_html__( 'Slide items List', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ name }}}',
			]
		);

		$this->end_controls_section();




/*
==========
Style Tab
==========
*/

		$this->start_controls_section(
			'general_section',
			[
				'label' => __( 'General', 'themevally-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'select_style',
				[
					'label' => __( 'Select Style', 'themevally-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'options' => [
						'one' => __( 'One', 'themevally-elementor-extension' ),
						'two' => __( 'Two', 'themevally-elementor-extension' ),
						'three' => __( 'Three', 'themevally-elementor-extension' ),
						'four' => __( 'Four', 'themevally-elementor-extension' ),
						'five' => __( 'Five', 'themevally-elementor-extension' ),
						'six' => __( 'Six', 'themevally-elementor-extension' ),
						'seven' => __( 'Seven', 'themevally-elementor-extension' ),
						'eight' => __( 'Eight', 'themevally-elementor-extension' ),
						'nine' => __( 'Nine', 'themevally-elementor-extension' ),
					],
					'default' => 'one',
					
				]
			);
		$this->end_controls_section();
		
		$this->start_controls_section(
			'quote_section',
			[
				'label' => __( 'Quote', 'themevally-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'conditions' => [
				    'relation' => 'or',
					'terms' => [
						[
			                'terms' => [
				                [
			                        'name' => 'select_style',
			                        'operator' => '==',
			                        'value' => 'one'
			                    ],
			                ]
			            ],
			            [
			                'terms' => [
			                    [
			                         'name' => 'select_style',
			                         'operator' => '==',
			                         'value' => 'three'
				                ],
			                ]
						]
					]
				]
			]
		);
    		$this->add_control(
    			'quote_text_color',
    			[
    				'label' => __( 'Text Color', 'themevally-elementor-extension' ),
    				'type' => \Elementor\Controls_Manager::COLOR,
    				'selectors' => [
    					'{{WRAPPER}} .single_testimonial .testi_content .em_testi_text' => 'color: {{VALUE}}',
    				],
    			]
    		);
    		$this->add_control(
    			'quote_background_color',
    			[
    				'label' => __( 'Background Color', 'themevally-elementor-extension' ),
    				'type' => \Elementor\Controls_Manager::COLOR,
    				'selectors' => [
    					'{{WRAPPER}} .single_testimonial .testi_content' => 'background-color: {{VALUE}}',
    					'{{WRAPPER}} .single_testimonial .testi_content::before' => 'border-left-color: {{VALUE}}; border-top-color: {{VALUE}}',
    				],
    			]
    		);
		$this->end_controls_section();

		$this->start_controls_section(
			'icon_section_style',
			[
				'label' => __( 'Icon', 'themevally-elementor-extension' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'icon_color',
				[
					'label' => __( 'Icon Color', 'themevally-elementor-extension' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .testi_thumb:before' => 'color: {{VALUE}};',
					],
				]
			);
			
			$this->add_control(
				'icon_background_color',
				[
					'label' => __( 'Icon Background Color', 'themevally-elementor-extension' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .testi_thumb:before' => 'background-color: {{VALUE}};',
					],
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_section_style',
			[
				'label' => __( 'Content', 'themevally-elementor-extension' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
			
			$this->add_control(
				'name_color',
				[
					'label' => __( 'Name Color', 'themevally-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .testi_title h2' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'name_typography',
					'selector' => '{{WRAPPER}} .testi_title h2',
				]
			);
			$this->add_control(
				'designation_color',
				[
					'label' => __( 'Designation Color', 'themevally-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'separator' => 'before',
					'selectors' => [
						'{{WRAPPER}} .testi_title span' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'designation_typography',
					'selector' => '{{WRAPPER}} .testi_title span',
				]
			);

			$this->add_control(
				'quote_color',
				[
					'label' => __( 'Description Color', 'themevally-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'separator' => 'before',
					'selectors' => [
						'{{WRAPPER}} .testi_content .testi_text' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'quote_typography',
					'selector' => '{{WRAPPER}} .testi_content .testi_text',
				]
			);
			
			$this->add_control(
				'quote_title_color',
				[
					'label' => __( ' title Color', 'themevally-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'separator' => 'before',
					'selectors' => [
						'{{WRAPPER}} .testi_content .testi_title' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'quote_title_typography',
					'selector' => '{{WRAPPER}} .testi_content .testi_title',
				]
			);

			$this->add_control(
				'rating_color',
				[
					'label' => __( 'Rating Color', 'themevally-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'separator' => 'before',
					'selectors' => [
						'{{WRAPPER}} .testi-star i.active' => 'color: {{VALUE}};',
					],
				]
			);
			
		$this->end_controls_section();


		$this->start_controls_section(
			'content_section_style_box',
			[
				'label' => __( 'Box Background', 'themevally-elementor-extension' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'select_style' => 'eight'
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background_box',
				'label' => __( 'Background', 'themevally-elementor-extension' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .testimonial-style-8 .single_testimonial',
			]
		);

		$this->end_controls_section();
		
		$this->start_controls_section(
			'box_section_style',
			[
				'label' => __( 'Box', 'themevally-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->start_controls_tabs(
				'box_style_tabs'
			);
				$this->start_controls_tab(
					'box_style_normal_tab',
					[
						'label' => __( 'Normal', 'themevally-elementor-extension' ),
					]
				);
				
					$this->add_group_control(
						\Elementor\Group_Control_Border::get_type(),
						[
							'name' => 'box_border',
							'label' => __( 'Border', 'themevally-elementor-extension' ),
							'selector' => '{{WRAPPER}} .single_testimonial',
						]
					);

					$this->add_responsive_control(
						'box_border_radius',
						[
							'label' => __( 'Border Radius', 'themevally-elementor-extension' ),
							'type' => \Elementor\Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', 'em', '%' ],
							'selectors' => [
								'{{WRAPPER}} .single_testimonial' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);

					$this->add_group_control(
						\Elementor\Group_Control_Box_Shadow::get_type(),
						[
							'name' => 'box_shadow',
							'label' => __( 'Box Shadow', 'themevally-elementor-extension' ),
							'selector' => '{{WRAPPER}} .single_testimonial',
						]
					);

					$this->add_group_control(
						\Elementor\Group_Control_Background::get_type(),
						[
							'name' => 'box_background',
							'label' => __( 'Background', 'themevally-elementor-extension' ),
							'types' => [ 'classic', 'gradient', 'video' ],
							'selector' => '{{WRAPPER}} .single_testimonial',
						]
					);
				
				$this->end_controls_tab();
				
				$this->start_controls_tab(
					'box_style_hover_tab',
					[
						'label' => __( 'Hover', 'themevally-elementor-extension' ),
					]
				);

					$this->add_group_control(
						\Elementor\Group_Control_Border::get_type(),
						[
							'name' => 'hover_box_border',
							'label' => __( 'Border', 'themevally-elementor-extension' ),
							'selector' => '{{WRAPPER}} .single_testimonial:hover',
						]
					);

					$this->add_responsive_control(
						'hover_box_border_radius',
						[
							'label' => __( 'Border Radius', 'themevally-elementor-extension' ),
							'type' => \Elementor\Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', 'em', '%' ],
							'selectors' => [
								'{{WRAPPER}} .single_testimonial:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);

					$this->add_group_control(
						\Elementor\Group_Control_Box_Shadow::get_type(),
						[
							'name' => 'hover_box_shadow',
							'label' => __( 'Box Shadow', 'themevally-elementor-extension' ),
							'selector' => '{{WRAPPER}} .single_testimonial:hover',
						]
					);

					$this->add_group_control(
						\Elementor\Group_Control_Background::get_type(),
						[
							'name' => 'hover_box_background',
							'label' => __( 'Background', 'themevally-elementor-extension' ),
							'types' => [ 'classic', 'gradient', 'video' ],
							'selector' => '{{WRAPPER}} .single_testimonial:hover',
						]
					);
				
				$this->end_controls_tab();
				
			$this->end_controls_tabs();

			$this->add_responsive_control(
				'box_margin',
				[
					'label' => __( 'Margin', 'themevally-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .single_testimonial' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);
			$this->add_responsive_control(
				'box_padding',
				[
					'label' => __( 'Padding', 'themevally-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .single_testimonial' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();
		
	}

	protected function render() {

		$settings = $this->get_settings_for_display();


		?>
		

		<?php if($settings['select_style']=='one'){ ?>

			<div class="testimonial_list owl-carousel owl-loaded curosel-style">

				<?php foreach ( $settings['list'] as $item  ) { ?>
				<div class="col-md-12">	

					<div class="single_testimonial default-style">
													
						<div class="testi_thumb">
							<img src="<?php echo $item['image']['url']; ?>" alt="">
						</div>
													
						<div class="testi_content">
							<div class="testi_text">
								<?php echo $item['quote_text']; ?>
							</div>
						</div>

						<div class="reviews_rating">

							<?php if( $item['rating']==5 ){ ?>
							<div class="testi-star">
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
							</div>
							<?php } ?>				
							
							<?php if( $item['rating']==4 ){ ?>			
							<div class="testi-star">
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star"></i>
							</div>												
							<?php } ?>
							
							<?php if( $item['rating']==3 ){ ?>
							<div class="testi-star">
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
							</div>												
							<?php } ?>
							
							<?php if( $item['rating']==2 ){ ?>
							<div class="testi-star">
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
							</div>												
							<?php } ?>
							
							<?php if( $item['rating']==1 ){ ?>
							<div class="testi-star">
								<i class="fa fa-star active"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
							</div>
							<?php } ?>
						</div><!-- .reviews_rating -->

						<div class="testi_title">
							<h2><?php echo $item['name']; ?><span><?php echo $item['designation']; ?></span></h2>
						</div>

					</div>
				</div>
				<?php } ?>
			</div>
            <script>
            	jQuery(document).ready(function($) {
            		"use strict";
            		$('.testimonial_list').owlCarousel({
            		loop: true,
            		autoplay: false,
            		autoplayTimeout: 10000,
            		dots: true,
            		nav: false,
            		navText: ["<i class='flaticon-back-1'></i>", "<i class='fa fa-angle-right'></i>"],
            		responsive: {
            			0: {
            				items: 1
            			},
            			768: {
            				items: 2
            			},
            			992: {
            				items: 2
            			},
            			1000: {
            				items: 3
            			},
            			1920: {
            				items: 3,
            			}
            		}
            	})
            	});
            </script>			

		<?php }elseif($settings['select_style']=='two'){ ?>


			<div class="testimonial_list2 owl-carousel owl-loaded curosel-style testimonial-style-two">												
				<?php foreach ( $settings['list'] as $item  ) { ?>
				<div class="col-md-12">	

					<div class="single_testimonial">
												
						<div class="testi_thumb">
							<img src="<?php echo $item['image']['url']; ?>" alt="">
						</div>
						
						<div class="testi_content">
							<div class="testi_text">
								<?php echo $item['quote_text']; ?>
							</div>
						</div>

						<div class="em_reviews_rating">																								
						<?php if($em_rating==5){?> 
							<div class="testi-star">
													
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
							</div>										
												
						<?php }elseif($em_rating==4){?>
							<div class="testi-star">
							
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star"></i>
							
							</div>												

						<?php }elseif($em_rating==3){?>
							<div class="testi-star">
							
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
							
							</div>												

						<?php }elseif($em_rating==2){?>
							<div class="testi-star">
							
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
							
							</div>												

						<?php }elseif($em_rating==1){?>
							<div class="testi-star">
							
								<i class="fa fa-star active"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
							
							</div>	
						<?php }else{}?>
					</div>
						<div class="testi_title">
							<h2><?php echo $item['name']; ?><span><?php echo $item['designation']; ?></span></h2>
						</div>

					</div>										

				</div>
				<?php } ?>								
									
			</div>
            <script>
            	jQuery(document).ready(function($) {
            		"use strict";
                	// 6.EM TESTIMONIAL
                	$('.testimonial_list2').owlCarousel({
                		loop: true,
                		autoplay: false,
                		autoplayTimeout: 10000,
                		dots: true,
                		nav: false,
                		navText: ["<i class='flaticon-back-1'></i>", "<i class='fa fa-angle-right'></i>"],
                		responsive: {
                			0: {
                				items: 1
                			},
                			768: {
                				items: 1
                			},
                			992: {
                				items: 1
                			},
                			1000: {
                				items: 1
                			},
                			1920: {
                				items: 1,
                			}
                		}
                	})
            	});
            </script>

		<?php }elseif($settings['select_style']=='three'){ ?>

			<div class="testimonial_list owl-carousel owl-loaded curosel-style owl-loaded owl-drag testimonial-style-three">

				<?php foreach ( $settings['list'] as $item  ) { ?>
				<div class="col-md-12">	

					<div class="single_testimonial">
													
						
													
						<div class="testi_content">
							<div class="em_testi_text">
								<?php echo $item['quote_text']; ?>
							</div>
						</div>

						<div class="test_thumb">
							<img src="<?php echo $item['image']['url']; ?>" alt="">
						</div>

						<div class="testi_title">

							<div class="reviews_rating">

								<?php if( $item['rating']==5 ){ ?>
								<div class="testi-star">
									<i class="fa fa-star active"></i>
									<i class="fa fa-star active"></i>
									<i class="fa fa-star active"></i>
									<i class="fa fa-star active"></i>
									<i class="fa fa-star active"></i>
								</div>
								<?php } ?>				
								
								<?php if( $item['rating']==4 ){ ?>			
								<div class="testi-star">
									<i class="fa fa-star active"></i>
									<i class="fa fa-star active"></i>
									<i class="fa fa-star active"></i>
									<i class="fa fa-star active"></i>
									<i class="fa fa-star"></i>
								</div>												
								<?php } ?>
								
								<?php if( $item['rating']==3 ){ ?>
								<div class="testi-star">
									<i class="fa fa-star active"></i>
									<i class="fa fa-star active"></i>
									<i class="fa fa-star active"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
								</div>												
								<?php } ?>
								
								<?php if( $item['rating']==2 ){ ?>
								<div class="testi-star">
									<i class="fa fa-star active"></i>
									<i class="fa fa-star active"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
								</div>												
								<?php } ?>
								
								<?php if( $item['rating']==1 ){ ?>
								<div class="testi-star">
									<i class="fa fa-star active"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
								</div>
								<?php } ?>
							</div><!-- .reviews_rating -->

							<h2><?php echo $item['name']; ?><span><?php echo $item['designation']; ?></span></h2>
						</div>

					</div>
				</div>
				<?php } ?>
			</div>
            <script>
            	jQuery(document).ready(function($) {
            		"use strict";
            		$('.testimonial_list').owlCarousel({
            		loop: true,
            		autoplay: false,
            		autoplayTimeout: 10000,
            		dots: true,
            		nav: false,
            		navText: ["<i class='flaticon-back-1'></i>", "<i class='fa fa-angle-right'></i>"],
            		responsive: {
            			0: {
            				items: 1
            			},
            			768: {
            				items: 2
            			},
            			992: {
            				items: 2
            			},
            			1000: {
            				items: 3
            			},
            			1920: {
            				items: 3,
            			}
            		}
            	})
            	});
            </script>			
		
		<?php }elseif($settings['select_style']=='four'){ ?>

			<div class="testimonial_list owl-carousel owl-loaded curosel-style testimonial-style-four">

				<?php foreach ( $settings['list'] as $item  ) { ?>
				<div class="col-md-12">	

					<div class="single_testimonial">
													
						<div class="testi_thumb">
							<img src="<?php echo $item['image']['url']; ?>" alt="">
						</div>
													
						<div class="testi_content">
							<div class="testi_text">
								<?php echo $item['quote_text']; ?>
							</div>
						</div>

						<div class="reviews_rating">

							<?php if( $item['rating']==5 ){ ?>
							<div class="testi-star">
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
							</div>
							<?php } ?>				
							
							<?php if( $item['rating']==4 ){ ?>			
							<div class="testi-star">
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star"></i>
							</div>												
							<?php } ?>
							<?php if( $item['rating']==3 ){ ?>
							<div class="testi-star">
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
							</div>												
							<?php } ?>
							
							<?php if( $item['rating']==2 ){ ?>
							<div class="testi-star">
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
							</div>												
							<?php } ?>
							
							<?php if( $item['rating']==1 ){ ?>
							<div class="testi-star">
								<i class="fa fa-star active"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
							</div>
							<?php } ?>
						</div><!-- .reviews_rating -->
						<div class="testi_title">
							<h2><?php echo $item['name']; ?><span><?php echo $item['designation']; ?></span></h2>
						</div>

					</div>
				</div>
				<?php } ?>
			</div>
            <script>
            	jQuery(document).ready(function($) {
            		"use strict";
            		$('.testimonial_list').owlCarousel({
            		loop: true,
            		autoplay: false,
            		autoplayTimeout: 10000,
            		dots: true,
            		nav: false,
            		navText: ["<i class='flaticon-back-1'></i>", "<i class='fa fa-angle-right'></i>"],
            		responsive: {
            			0: {
            				items: 1
            			},
            			768: {
            				items: 2
            			},
            			992: {
            				items: 2
            			},
            			1000: {
            				items: 3
            			},
            			1920: {
            				items: 3,
            			}
            		}
            	})
            	});
            </script>			

		<?php } elseif($settings['select_style']=='five'){ ?>

			<div class="testimonial_list owl-carousel owl-loaded curosel-style testimonial-style-five">

				<?php foreach ( $settings['list'] as $item  ) { ?>
				<div class="col-md-12">	

					<div class="single_testimonial">
													
						<div class="testi_content_inner">
							<div class="testi_text_two">
								<?php echo $item['quote_title']; ?>
							</div>
						</div>
													
						<div class="testi_content">
							<div class="testi_text">
								<?php echo $item['quote_text']; ?>
							</div>
						</div>
						<div class="testi_thumb">
							<img src="<?php echo $item['image']['url']; ?>" alt="">
						</div>
						<div class="testi_title">
							<h2><?php echo $item['name']; ?><span><?php echo $item['designation']; ?></span></h2>
						</div>

					</div>
				</div>
				<?php } ?>
			</div>
            <script>
            	jQuery(document).ready(function($) {
            		"use strict";
            		$('.testimonial_list').owlCarousel({
            		loop: true,
            		autoplay: false,
            		autoplayTimeout: 10000,
            		dots: true,
            		nav: false,
            		navText: ["<i class='flaticon-back-1'></i>", "<i class='fa fa-angle-right'></i>"],
            		responsive: {
            			0: {
            				items: 1
            			},
            			768: {
            				items: 1
            			},
            			992: {
            				items: 1
            			},
            			1000: {
            				items: 1
            			},
            			1920: {
            				items:1,
            			}
            		}
            	})
            	});
            </script>	


  		

		<?php }elseif($settings['select_style']=='six'){ ?>

			<div class="testimonial_list owl-carousel owl-loaded curosel-style testimonial-style-six">

				<?php foreach ( $settings['list'] as $item  ) { ?>
				<div class="col-md-12">	

					<div class="single_testimonial">
													
						<div class="testi_thumb">
							<img src="<?php echo $item['image']['url']; ?>" alt="">
						</div>
													
						<div class="testi_content">
							<div class="testi_text">
								<?php echo $item['quote_text']; ?>
							</div>
						</div>

						<div class="reviews_rating">

							<?php if( $item['rating']==5 ){ ?>
							<div class="testi-star">
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
							</div>
							<?php } ?>				
							
							<?php if( $item['rating']==4 ){ ?>			
							<div class="testi-star">
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star"></i>
							</div>												
							<?php } ?>
							<?php if( $item['rating']==3 ){ ?>
							<div class="testi-star">
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
							</div>												
							<?php } ?>
							
							<?php if( $item['rating']==2 ){ ?>
							<div class="testi-star">
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
							</div>												
							<?php } ?>
							
							<?php if( $item['rating']==1 ){ ?>
							<div class="testi-star">
								<i class="fa fa-star active"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
							</div>
							<?php } ?>
						</div><!-- .reviews_rating -->
						<div class="testi_title">
							<h2><?php echo $item['name']; ?><span><?php echo $item['designation']; ?></span></h2>
						</div>

					</div>
				</div>
				<?php } ?>
			</div>
            <script>
            	jQuery(document).ready(function($) {
            		"use strict";
            		$('.testimonial_list').owlCarousel({
            		loop: true,
            		autoplay: false,
            		autoplayTimeout: 10000,
            		dots: false,
            		nav: true,
            		navText: ["<i class='flaticon flaticon-left-arrow'></i>", "<i class='flaticon flaticon-right-arrow'></i>"],
            		responsive: {
            			0: {
            				items: 1
            			},
            			768: {
            				items: 2
            			},
            			992: {
            				items: 2
            			},
            			1000: {
            				items: 3
            			},
            			1365: {
            				items: 3
            			},
            			1920: {
            				items: 3,
            			}
            		}
            	})
            	});
            </script>			

		<?php }elseif($settings['select_style']=='seven'){ ?>

			<div class="testimonial_list owl-carousel owl-loaded curosel-style testimonial-style-seven">

				<?php foreach ( $settings['list'] as $item  ) { ?>
				<div class="col-md-12">	

					<div class="single_testimonial">
						
						<div class="testi_thumb">
							<img src="<?php echo $item['image']['url']; ?>" alt="">
						</div>
						
						<div class="testi_content">
							<div class="testi_text">
								<?php echo $item['quote_text']; ?>
							</div>
							<div class="testi_title">
								<h2><?php echo $item['name']; ?><span><?php echo $item['designation']; ?></span></h2>
							</div>
						</div>
						

					</div>
				</div>
				<?php } ?>
			</div>
            <script>
            	jQuery(document).ready(function($) {
            		"use strict";
            		$('.testimonial_list').owlCarousel({
            		loop: true,
            		autoplay: false,
            		autoplayTimeout: 10000,
            		dots: false,
            		nav: true,
            		navText: ["<i class='flaticon flaticon-left-arrow'></i>", "<i class='flaticon flaticon-right-arrow'></i>"],
            		responsive: {
            			0: {
            				items: 1
            			},
            			768: {
            				items: 2
            			},
            			992: {
            				items: 2
            			},
            			1000: {
            				items: 2
            			},
            			1365: {
            				items: 2
            			},
            			1920: {
            				items: 2,
            			}
            		}
            	})
            	});
            </script>			

		<?php }elseif($settings['select_style']=='eight'){ ?>

			<div class="testimonial_list owl-carousel owl-loaded curosel-style testimonial-style-8">

				<?php foreach ( $settings['list'] as $item  ) { ?>
				<div class="col-md-12">	

					<div class="single_testimonial">
													
						<div class="new-testimonial d-flex align-items-center">
							<div class="testi_thumb">
								<img src="<?php echo $item['image']['url']; ?>" alt="">
							</div>
							<div class="testi_title">
								<h2><?php echo $item['name']; ?><span><?php echo $item['designation']; ?></span></h2>
							</div>
						</div>

						<div class="testi_content">
							<div class="testi_text">
								<?php echo $item['quote_text']; ?>
							</div>
						</div>

						<div class="reviews_rating">

							<?php if( $item['rating']==5 ){ ?>
							<div class="testi-star">
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
							</div>
							<?php } ?>				
							
							<?php if( $item['rating']==4 ){ ?>			
							<div class="testi-star">
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star"></i>
							</div>												
							<?php } ?>
							<?php if( $item['rating']==3 ){ ?>
							<div class="testi-star">
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
							</div>												
							<?php } ?>
							
							<?php if( $item['rating']==2 ){ ?>
							<div class="testi-star">
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
							</div>												
							<?php } ?>
							
							<?php if( $item['rating']==1 ){ ?>
							<div class="testi-star">
								<i class="fa fa-star active"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
							</div>
							<?php } ?>
						</div><!-- .reviews_rating -->
						

					</div>
				</div>
				<?php } ?>
			</div>
            <script>
            	jQuery(document).ready(function($) {
            		"use strict";
            		$('.testimonial_list').owlCarousel({
            		loop: true,
            		autoplay:true,
            		autoplayTimeout: 10000,
            		dots:true,
            		nav:false,
            		navText: ["<i class='flaticon flaticon-left-arrow'></i>", "<i class='flaticon flaticon-right-arrow'></i>"],
            		responsive: {
            			0: {
            				items: 1
            			},
            			768: {
            				items: 1
            			},
            			992: {
            				items: 1
            			},
            			1000: {
            				items:1
            			},
            			1365: {
            				items: 1
            			},
            			1920: {
            				items:1,
            			}
            		}
            	})
            	});
            </script>			

		<?php }elseif($settings['select_style']=='nine'){ ?>


			<div class="testimonial_list2 owl-carousel owl-loaded curosel-style testimonial-style9">												
				<?php foreach ( $settings['list'] as $item  ) { ?>
				<div class="col-md-12">	

					<div class="single_testimonial">
												
						<div class="testi_thumb">
							<img src="<?php echo $item['image']['url']; ?>" alt="">
						</div>
						
						<div class="testi_content">
						    <div class="testi_title">
								<?php echo $item['quote_title']; ?>
							</div>
							<div class="testi_text">
								<?php echo $item['quote_text']; ?>
							</div>
						</div>

						<div class="em_reviews_rating">																								
						<?php if($em_rating==5){?> 
							<div class="testi-star">
													
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
							</div>										
												
						<?php }elseif($em_rating==4){?>
							<div class="testi-star">
							
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star"></i>
							
							</div>												

						<?php }elseif($em_rating==3){?>
							<div class="testi-star">
							
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
							
							</div>												

						<?php }elseif($em_rating==2){?>
							<div class="testi-star">
							
								<i class="fa fa-star active"></i>
								<i class="fa fa-star active"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
							
							</div>												

						<?php }elseif($em_rating==1){?>
							<div class="testi-star">
							
								<i class="fa fa-star active"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
							
							</div>	
						<?php }else{}?>
					</div>
					<div class="testi_title">
						<h2><?php echo $item['name']; ?><span><?php echo $item['designation']; ?></span></h2>
					</div>

					</div>										

				</div>
				<?php } ?>								
									
			</div>
            <script>
            	jQuery(document).ready(function($) {
            		"use strict";
                	// 6.EM TESTIMONIAL
                	$('.testimonial_list2').owlCarousel({
                		loop: true,
                		autoplay: false,
                		autoplayTimeout: 10000,
                		dots: true,
                		nav: false,
                		navText: ["<i class='flaticon-back-1'></i>", "<i class='fa fa-angle-right'></i>"],
                		responsive: {
                			0: {
                				items: 1
                			},
                			768: {
                				items: 1
                			},
                			992: {
                				items: 1
                			},
                			1000: {
                				items: 1
                			},
                			1920: {
                				items: 1,
                			}
                		}
                	})
            	});
            </script>

		<?php }?>
							
		<?php
	}
}

