<?php



use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if(!defined('ABSPATH')) exit;


class themevallyButton extends Widget_Base{

	public function get_name(){
		return "dit-button";
	}
	
	public function get_title(){
		return "themevally Button";
	}
	
	public function get_icon(){
		return "eicon-fb-feed";
	}

	public function get_categories(){
		return ['themevally-category'];
	}

	protected function register_controls(){

		$this->start_controls_section(
			'button_section',
			[
				'label' => __( 'Button', 'themevally-elementor-extension' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
			$this->add_control(
				'button_text',
				[
					'label' => __( 'Button Text', 'themevally-elementor-extension' ),
					'type' => Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'Enter your button text', 'themevally-elementor-extension' ),
					'label_block' => true,
					'default' => __( 'Button', 'themevally-elementor-extension' ),
				]
			);
			$this->add_control(
				'button_url',
				[
					'label' => __( 'Button URL', 'themevally-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::URL,
					'placeholder' => __( 'https://your-link.com', 'themevally-elementor-extension' ),
				]
			);
			$this->add_control(
				'show_button',
				[
					'label' => __( 'Show Button', 'themevally-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => __( 'Show', 'themevally-elementor-extension' ),
					'label_off' => __( 'Hide', 'themevally-elementor-extension' ),
					'return_value' => 'yes',
					'default' => 'no',
				]
			);
			$this->add_control(
				'button_icon',
				[
					'label' => __( 'Button Icon', 'themevally-elementor-extension' ),
					'type' => Controls_Manager::ICONS,
				]
			);
		$this->end_controls_section();

/*
==========
Style Tab
==========
*/

		$this->start_controls_section(
			'general_section',
			[
				'label' => __( 'General', 'themevally-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'select_style',
				[
					'label' => __( 'Select Style', 'themevally-elementor-extension' ),
					'type' => Controls_Manager::SELECT,
					'options' => [
						'one' => __( 'One', 'themevally-elementor-extension' ),
						'two' => __( 'Two', 'themevally-elementor-extension' ),
						'three' => __( 'Three', 'themevally-elementor-extension' ),
						'four' => __( 'Four', 'themevally-elementor-extension' ),

					],
					'default' => 'one',
					
				]
			);
			$this->add_responsive_control(
				'text_align',
				[
					'label' => __( 'Alignment', 'themevally-elementor-extension' ),
					'type' => Controls_Manager::CHOOSE,
					'options' => [
						'left' => [
							'title' => __( 'Left', 'themevally-elementor-extension' ),
							'icon' => 'eicon-text-align-left',
						],
						'center' => [
							'title' => __( 'Center', 'themevally-elementor-extension' ),
							'icon' => 'eicon-text-align-center',
						],
						'right' => [
							'title' => __( 'Right', 'themevally-elementor-extension' ),
							'icon' => 'eicon-text-align-right',
						],
						'justify' => [
							'title' => __( 'Justified', 'themevally-elementor-extension' ),
							'icon' => 'eicon-text-align-justify',
						],
					],
					'selectors' => [
						'{{WRAPPER}} .themevally-button-box' => 'text-align: {{VALUE}};',
					],
				]
			);
		$this->end_controls_section();


		$this->start_controls_section(
			'icon_section_style',
			[
				'label' => __( 'Icon', 'themevally-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs(
			'style_tabs'
		);
		$this->start_controls_tab(
			'style_normal_tab',
			[
				'label' => __( 'Normal', 'themevally-elementor-extension' ),
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

			$this->add_control(
				'height',
				[
					'label' => __( 'Height', 'themevally-elementor-extension' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1000,
							'step' => 5,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .themevally-button-box .themevally-button-box-icon i' => 'height: {{SIZE}}{{UNIT}};',
					],
				]
			);
			$this->add_control(
				'width',
				[
					'label' => __( 'Width', 'themevally-elementor-extension' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1000,
							'step' => 5,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .themevally-button-box .themevally-button-box-icon i' => 'width: {{SIZE}}{{UNIT}};',
					],
				]
			);
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'icon_typography',
					'selector' => '{{WRAPPER}} .themevally-button-box .themevally-button-box-icon i',
				]
			);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'content_section_style',
			[
				'label' => __( 'Content', 'themevally-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'heading_title',
				[
					'label' => __( 'Title', 'themevally-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);
			
			
    		$this->start_controls_tabs(
    			'title_tabs'
    		);
    		
        		$this->start_controls_tab(
        			'title_normal_tab',
        			[
        				'label' => __( 'Normal', 'themevally-elementor-extension' ),
        			]
        		);
        			$this->add_control(
        				'title_color',
        				[
        					'label' => __( 'Color', 'themevally-elementor-extension' ),
        					'type' => \Elementor\Controls_Manager::COLOR,
        					'default' => '',
        					'selectors' => [
        						'{{WRAPPER}} .themevally-button-box .themevally-button-box-title h2' => 'color: {{VALUE}};',
        					],
        				]
        			);
        			$this->add_group_control(
        				\Elementor\Group_Control_Typography::get_type(),
        				[
        					'name' => 'title_typography',
        					'selector' => '{{WRAPPER}} .themevally-button-box .themevally-button-box-title h2, {{WRAPPER}} .elementor-icon-box-content .elementor-icon-box-title a',
        				]
        			);
        		$this->end_controls_tab();
        		
        		$this->start_controls_tab(
        			'title_hover_tab',
        			[
        				'label' => __( 'Hover', 'themevally-elementor-extension' ),
        			]
        		);
        			$this->add_control(
        				'title_hover_color',
        				[
        					'label' => __( 'Color', 'themevally-elementor-extension' ),
        					'type' => \Elementor\Controls_Manager::COLOR,
        					'default' => '',
        					'selectors' => [
        						'{{WRAPPER}} .themevally-button-box:hover .themevally-button-box-title h2' => 'color: {{VALUE}};',
        					],
        				]
        			);
        			$this->add_group_control(
        				\Elementor\Group_Control_Typography::get_type(),
        				[
        					'name' => 'title_hover_typography',
        					'selector' => '{{WRAPPER}} .themevally-button-box:hover .themevally-button-box-title h2, {{WRAPPER}} .elementor-icon-box-content .elementor-icon-box-title a',
        				]
        			);
        		$this->end_controls_tab();
    		
    		$this->end_controls_tabs();
			
			$this->add_control(
				'heading_description',
				[
					'label' => __( 'Description', 'themevally-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);
			
    		$this->start_controls_tabs(
    			'description_tabs'
    		);
    		
        		$this->start_controls_tab(
        			'description_normal_tab',
        			[
        				'label' => __( 'Normal', 'themevally-elementor-extension' ),
        			]
        		);

        			$this->add_control(
        				'description_color',
        				[
        					'label' => __( 'Color', 'themevally-elementor-extension' ),
        					'type' => \Elementor\Controls_Manager::COLOR,
        					'default' => '',
        					'selectors' => [
        						'{{WRAPPER}} .themevally-button-box .themevally-button-box-desc p' => 'color: {{VALUE}};',
        					],
        				]
        			);
        
        			$this->add_group_control(
        				\Elementor\Group_Control_Typography::get_type(),
        				[
        					'name' => 'description_typography',
        					'selector' => '{{WRAPPER}} .themevally-button-box-desc p',
        				]
        			);
        		
        		$this->end_controls_tab();
        		
        		$this->start_controls_tab(
        			'description_hover_tab',
        			[
        				'label' => __( 'Hover', 'themevally-elementor-extension' ),
        			]
        		);
        		
        			$this->add_control(
        				'description_hover_color',
        				[
        					'label' => __( 'Color', 'themevally-elementor-extension' ),
        					'type' => \Elementor\Controls_Manager::COLOR,
        					'default' => '',
        					'selectors' => [
        						'{{WRAPPER}} .themevally-button-box:hover .themevally-button-box-desc p' => 'color: {{VALUE}};',
        					],
        				]
        			);
        
        			$this->add_group_control(
        				\Elementor\Group_Control_Typography::get_type(),
        				[
        					'name' => 'description_hover_typography',
        					'selector' => '{{WRAPPER}} .themevally-button-box:hover .themevally-button-box-desc p',
        				]
        			);	
        		
        		$this->end_controls_tab();
    		
    		$this->end_controls_tabs();
			
		$this->end_controls_section();

		$this->start_controls_section(
			'box_section_style',
			[
				'label' => __( 'Box', 'themevally-elementor-extension' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'css_class',
				[
					'label' => __( 'CSS Class', 'themevally-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
				]
			);
			$this->start_controls_tabs(
				'box_style_tabs'
			);
				$this->start_controls_tab(
					'box_style_normal_tab',
					[
						'label' => __( 'Normal', 'themevally-elementor-extension' ),
					]
				);
				
					$this->add_group_control(
						\Elementor\Group_Control_Border::get_type(),
						[
							'name' => 'box_border',
							'label' => __( 'Border', 'themevally-elementor-extension' ),
							'selector' => '{{WRAPPER}} .themevally-button-box',
						]
					);

					$this->add_responsive_control(
						'box_border_radius',
						[
							'label' => __( 'Border Radius', 'themevally-elementor-extension' ),
							'type' => \Elementor\Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', 'em', '%' ],
							'selectors' => [
								'{{WRAPPER}} .themevally-button-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);

					$this->add_group_control(
						\Elementor\Group_Control_Box_Shadow::get_type(),
						[
							'name' => 'box_shadow',
							'label' => __( 'Box Shadow', 'themevally-elementor-extension' ),
							'selector' => '{{WRAPPER}} .themevally-button-box',
						]
					);

					$this->add_group_control(
						\Elementor\Group_Control_Background::get_type(),
						[
							'name' => 'box_background',
							'label' => __( 'Background', 'themevally-elementor-extension' ),
							'types' => [ 'classic', 'gradient', 'video' ],
							'selector' => '{{WRAPPER}} .themevally-button-box',
						]
					);
				
				$this->end_controls_tab();
				
				$this->start_controls_tab(
					'box_style_hover_tab',
					[
						'label' => __( 'Hover', 'themevally-elementor-extension' ),
					]
				);

					$this->add_group_control(
						\Elementor\Group_Control_Border::get_type(),
						[
							'name' => 'hover_box_border',
							'label' => __( 'Border', 'themevally-elementor-extension' ),
							'selector' => '{{WRAPPER}} .themevally-button-box:hover',
						]
					);

					$this->add_responsive_control(
						'hover_box_border_radius',
						[
							'label' => __( 'Border Radius', 'themevally-elementor-extension' ),
							'type' => \Elementor\Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', 'em', '%' ],
							'selectors' => [
								'{{WRAPPER}} .themevally-button-box:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);

					$this->add_group_control(
						\Elementor\Group_Control_Box_Shadow::get_type(),
						[
							'name' => 'hover_box_shadow',
							'label' => __( 'Box Shadow', 'themevally-elementor-extension' ),
							'selector' => '{{WRAPPER}} .themevally-button-box:hover',
						]
					);

					$this->add_group_control(
						\Elementor\Group_Control_Background::get_type(),
						[
							'name' => 'hover_box_background',
							'label' => __( 'Background', 'themevally-elementor-extension' ),
							'types' => [ 'classic', 'gradient', 'video' ],
							'selector' => '{{WRAPPER}} .themevally-button-box:hover',
						]
					);
				
				$this->end_controls_tab();
				
			$this->end_controls_tabs();

			$this->add_responsive_control(
				'box_margin',
				[
					'label' => __( 'Margin', 'themevally-elementor-extension' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .themevally-button-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);
			$this->add_responsive_control(
				'box_padding',
				[
					'label' => __( 'Padding', 'themevally-elementor-extension' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .themevally-button-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();

	}

	protected function render() {

		$settings = $this->get_settings_for_display();

	
		

		?>

		<?php if($settings['select_style']=='one'){ ?>

				<div class="themevally-button-box">
					<?php if( 'yes'===$settings['show_button'] ){ ?>
					<div class="themevally-button">
						<a href="#">
							<?php echo $settings['button_text']; ?>
							<i class="<?php echo esc_attr($settings['button_icon']['value']); ?>"></i>
						</a>
					</div>
					<?php } ?>
				</div>

		<?php }elseif($settings['select_style']=='two'){ ?>		
				<div class="themevally-button-box style2">
					<?php if( 'yes'===$settings['show_button'] ){ ?>
					<div class="themevally-button">
						<a href="<?php echo esc_url( $settings['button_url']['url']); ?>">
							<?php echo $settings['button_text']; ?>
							<i class="<?php echo esc_attr($settings['button_icon']['value']); ?>"></i>						</a>
					</div>
					<?php } ?>
				</div>
			<?php }elseif($settings['select_style']=='three'){ ?>		
				<div class="themevally-button-box style3">
					<?php if( 'yes'===$settings['show_button'] ){ ?>
					<div class="themevally-button">
						<a href="#">
							<?php echo $settings['button_text']; ?>
							<i class="<?php echo esc_attr($settings['button_icon']['value']); ?>"></i>						</a>
					</div>
					<?php } ?>
				</div>
			<?php }elseif($settings['select_style']=='four'){ ?>		
				<div class="themevally-button-box style4">
					<?php if( 'yes'===$settings['show_button'] ){ ?>
					<div class="themevally-button">
						<a href="#">
							<?php echo $settings['button_text']; ?>
							<i class="<?php echo esc_attr($settings['button_icon']['value']); ?>"></i>						
						</a>
					</div>
					<?php } ?>
				</div>

		<?php } ?>

	<?php
	}
}